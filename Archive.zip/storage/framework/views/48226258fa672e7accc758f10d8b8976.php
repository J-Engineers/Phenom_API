Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p>
<br>

<a href="<?php echo e($link); ?>">Click Here to continue...</a><?php /**PATH C:\xampp1\htdocs\phenom\resources\views/emails/registrationVerification.blade.php ENDPATH**/ ?>