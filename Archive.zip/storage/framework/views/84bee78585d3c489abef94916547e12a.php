Hello <strong><?php echo e($name); ?></strong>,
<p><?php echo e($body); ?></p>
<br>

<a href="<?php echo e($link); ?>">Click Here to continue...</a><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/phenom/resources/views/emails/registrationVerification.blade.php ENDPATH**/ ?>