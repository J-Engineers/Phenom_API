Hello <strong><?php echo e($name); ?></strong>,

<p><?php echo e($body); ?></p>

<h1>Token</h1>
<h2><?php echo e($token); ?></h2>
<br>

<a href="<?php echo e($link); ?>">Click Here to continue...</a><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/phenom/resources/views/emails/registration.blade.php ENDPATH**/ ?>